% layouts/тест/осн1.html.ep    

## {.класс1 .white-text #ид123 background-color: #435444; font-weight: 500; } Заголовок 2

{.chip grey       }параграфф

<script>
  console.log('123');
  <script src="/js/foo1.js">000</script>
  <foo>bar</foo>
</script>

<ul>
  <li>li1 text<span>{.class-span}li1 span1 text</span>li1 span2 text<i class="">li1 span2 icon1 text</i><span></span>l1 text after</li>
  <li><span>li2 span1 text</span>li2 span2 text<span></span>{.none} li2 text</li>
  <script src="/js/foo2.js"222</script>
</ul>

<script src="/js/foo3.js">333</script>