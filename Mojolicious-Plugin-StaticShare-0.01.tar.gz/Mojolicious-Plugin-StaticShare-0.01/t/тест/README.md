## Заголовок 2

<script>
console.log('123');
<script src="/js/foo1.js">000</script>
</script>

<script src="/js/foo2.js"></script>