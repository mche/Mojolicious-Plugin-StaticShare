% layouts/тест/осн1

# {.white-text .navy padding:0.5rem; #ид123} Заголовок

<script type="javascript">
  console.log('привет');
</script>

<script src="/foo.js"></script>